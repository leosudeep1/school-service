import { StatsProperties } from './../cards/stats-card/stats-card.component';
import { Component, OnInit } from '@angular/core';
import { BreakpointObserver, Breakpoints, BreakpointState } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({
  selector: 'app-component/main-nav',
  templateUrl: './main-nav.component.html',
  styleUrls: ['./main-nav.component.scss']
})
export class MainNavComponent implements OnInit {
  statsProps: StatsProperties[];
  public scrollbarOptions = { axis: 'yx', theme: 'minimal-dark' };

  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches)
    );

  constructor(private breakpointObserver: BreakpointObserver) { }
  ngOnInit() {
    this.statsProps = [
      {
        'cardHeaderColor': 'card-header-warning',
        'iconName': 'content_copy',
        'categoryName': 'Used Space',
        'categoryTitle': '49/50',
        'footerIcon': 'warning',
        'footerLink': '#',
        'footerText': 'Get More Space...'
      },
      {
        'cardHeaderColor': 'card-header-success',
        'iconName': 'store',
        'categoryName': 'Revenue',
        'categoryTitle': '$34,245',
        'footerIcon': 'date_range',
        'footerLink': '#',
        'footerText': 'Last 24 Hours'
      },
      {
        'cardHeaderColor': 'card-header-danger',
        'iconName': 'info_outline',
        'categoryName': 'Fixed Issues',
        'categoryTitle': '75',
        'footerIcon': 'local_offer',
        'footerLink': '#',
        'footerText': 'Tracked from Github'
      },
      {
        'cardHeaderColor': 'card-header-info',
        'iconName': 'fa fa-twitter',
        'categoryName': 'Followers',
        'categoryTitle': '+245',
        'footerIcon': 'update',
        'footerLink': '#',
        'footerText': 'Just Updated'
      }
    ]
  }

  print(any) {
    console.info(any);
  }

}
