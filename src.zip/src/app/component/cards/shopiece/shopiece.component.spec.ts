import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShopieceComponent } from './shopiece.component';

describe('ShopieceComponent', () => {
  let component: ShopieceComponent;
  let fixture: ComponentFixture<ShopieceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShopieceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShopieceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
