import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-stats-card',
  templateUrl: './stats-card.component.html',
  styleUrls: ['./stats-card.component.scss']
})
export class StatsCardComponent implements OnInit {

  @Input() props:StatsProperties;
 
  constructor() { }

  ngOnInit() {
  }

  print() {
    console.log(this.props);
  }

}

export interface StatsProperties {
  cardHeaderColor:String;
  iconName:String;
  categoryName:String;
  categoryTitle:String;
  footerIcon:String;
  footerLink:String;
  footerText:String;
}
