import { reducers } from './common/app.reducer';
import { MaterialModule } from './common/material.module';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { WelcomeComponent } from './component/welcome/welcome.component';
import { MainNavComponent } from './component/main-nav/main-nav.component';
import { FlexLayoutModule } from '@angular/flex-layout';
import { LayoutModule } from '@angular/cdk/layout';

import { HeaderComponent } from './component/nav/header/header.component';
import { FooterComponent } from './component/nav/footer/footer.component';
import { AppRoutingModule } from './common/app-routing.module';
import { StoreModule } from '@ngrx/store';
import { CarouselComponent } from './component/carousel/carousel.component';
import { ServiceSectionComponent } from './component/welcome/service-section/service-section.component';
import { TestimonialsSectionComponent } from './component/welcome/testimonials-section/testimonials-section.component';

import { FontAwesomeModule } from '@fortawesome/angular-fontawesome';
import { NguCarouselModule } from '@ngu/carousel';
import { ShopieceComponent } from './component/cards/shopiece/shopiece.component';
import { DashComponent } from './component/dash/dash.component';
import { MalihuScrollbarModule } from 'ngx-malihu-scrollbar';
import { SidenavListComponent } from './component/nav/sidenav-list/sidenav-list.component';
import { StatsCardComponent } from './component/cards/stats-card/stats-card.component';

@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    MainNavComponent,
    HeaderComponent,
    FooterComponent,
    CarouselComponent,
    ServiceSectionComponent,
    TestimonialsSectionComponent,
    ShopieceComponent,
    DashComponent,
    SidenavListComponent,
    StatsCardComponent,
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    LayoutModule,
    FlexLayoutModule,
    AppRoutingModule,
    MaterialModule,
    FontAwesomeModule,
    NguCarouselModule,
    StoreModule.forRoot(reducers),
    MalihuScrollbarModule.forRoot(),
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
