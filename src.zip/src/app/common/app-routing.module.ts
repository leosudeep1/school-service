import { AuthGuard } from './guards/auth.guard';
import { MainNavComponent } from './../component/main-nav/main-nav.component';
import { AnonymousGuard } from './guards/anonymous.guard';
import { WelcomeComponent } from './../component/welcome/welcome.component';

import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
    
    { path: '',  redirectTo: '/index',  pathMatch: 'full'},
    { path: 'index', component: WelcomeComponent, canActivate: [AnonymousGuard] }, //landing page
    { 
        path: 'home', 
        component: MainNavComponent, 
        // canActivate: [AuthGuard],
        children: [
           
        ]
    },
];

@NgModule({
    imports: [
        RouterModule.forRoot(routes)
    ],
    exports: [RouterModule],
    providers: [AuthGuard, AnonymousGuard]
})
export class AppRoutingModule { }