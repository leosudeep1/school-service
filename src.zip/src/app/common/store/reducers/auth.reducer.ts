import { AuthActions, SET_AUTHENTICATED, SET_UN_AUTHENTICATED } from './../actions/auth.action';

export interface State {
    isAuthencated: boolean;
    isAnonymous: boolean;
}

export const initialState: State = {
    isAuthencated: false,
    isAnonymous: true
}

export function authReducer(state = initialState, action : AuthActions) {
    switch(action.type) {
        case SET_AUTHENTICATED:
            return {
                isAuthencated: true,
                isAnonymous:false
            };
        case SET_UN_AUTHENTICATED:
            return {
                isAuthencated: false,
                isAnonymous: true
            };
        default:
            return state;
    }
}

export const getAuth = (state: State) => state.isAuthencated;
export const getAnonymous = (state: State) => state.isAnonymous;