import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carousel',
  templateUrl: './carousel.component.html',
  styleUrls: ['./carousel.component.scss']
})
export class CarouselComponent implements OnInit {
  sliders: Slider[];
  constructor() {
    this.sliders = [
      {
        imgName: '1',
        heading: 'One',
        text: 'this is number 1'
      },
      {
        imgName: '2',
        heading: 'Two',
        text: 'this is number 2'
      },
      {
        imgName: '3',
        heading: 'Three',
        text: 'this is number 3'
      },
      {
        imgName: '4',
        heading: 'Four',
        text: 'this is number 4'
      },
      {
        imgName: '5',
        heading: 'Five',
        text: 'this is number 5'
      }
    ]
  }

  ngOnInit() {
  }

}

export interface Slider {
  imgName: string;
  heading: string;
  text: string;
}
