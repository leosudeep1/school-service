import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidenav-list',
  templateUrl: './sidenav-list.component.html',
  styleUrls: ['./sidenav-list.component.scss']
})
export class SidenavListComponent implements OnInit {
  panelOpenState = false;
  navLists: any[];
  constructor() { }

  ngOnInit() {
    this.navLists = [{
      'type': 'single',
      'icon': 'home',
      'link': '/home',
      'iconType': 'mat',
      'linkName': 'Home'
    },
    {
      'type': 'accordian',
      'desc': 'Services',
      'iconType': 'mat',
      'icon': 'work_outline',
      'child_nav': [
        {
          'link': '/service/plumbering',
          'linkName': 'Plumbering'
        },
        {
          'link': '/service/fridge',
          'linkName': 'Fridge Repair'
        },
        {
          'link': '/service/washing-machine',
          'linkName': 'Washing Machine Repair'
        },
      ]
    },
    {
      'type': 'accordian',
      'desc': 'Profile',
      'iconType': 'mat',
      'icon': 'account_box',
      'child_nav': [
        {
          'link': '/profile/edit',
          'linkName': 'Edit'
        },
        {
          'link': '/service/view',
          'linkName': 'View Profile'
        }
      ]
    },
    {
      'type': 'single',
      'icon': 'home',
      'link': '/home',
      'iconType': 'mat',
      'linkName': 'Home'
    }
    ];
  }

}
