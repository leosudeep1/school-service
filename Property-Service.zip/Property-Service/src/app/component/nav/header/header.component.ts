import { Component, OnInit } from '@angular/core';
import { faFly } from '@fortawesome/free-brands-svg-icons';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {

  logo = faFly;
  constructor() { }

  ngOnInit() {
  }

}
