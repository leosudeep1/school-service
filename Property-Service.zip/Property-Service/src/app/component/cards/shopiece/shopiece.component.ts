import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-shopiece',
  templateUrl: './shopiece.component.html',
  styleUrls: ['./shopiece.component.scss']
})
export class ShopieceComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
