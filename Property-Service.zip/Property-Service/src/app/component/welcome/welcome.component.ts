import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.scss']
})
export class WelcomeComponent implements OnInit {
  services= [];
  constructor() { 
    this.services = [
      {
        'imgName':'image-01',
        'text': 'Beautiful Interiors'
      },
      {
        'imgName':'image-03',
        'text': 'Wellness and Relax Places'
      },
      {
        'imgName':'image-02',
        'text': 'Parking and Shopping'
      }
    ]
  }

  ngOnInit() {
  }


}
