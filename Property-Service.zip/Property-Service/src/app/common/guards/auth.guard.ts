import { Injectable } from '@angular/core';
import { CanActivate, RouterStateSnapshot, ActivatedRouteSnapshot, Router, Route } from "@angular/router";

import * as fromRoot from './../app.reducer';
import { Store } from '@ngrx/store';
import { take, filter, tap } from 'rxjs/operators';

@Injectable()
export class AuthGuard implements CanActivate {

    constructor(private store: Store<fromRoot.State>, private router: Router) { }
    isLoggedIn:boolean = false;
    canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
        //this.store.select(fromRoot.getIsAuthenticated).pipe(take(1));
       return this.store.select(fromRoot.getIsAuthenticated).pipe(tap(allowed => {
            if(!allowed) {
                this.router.navigate(['/index']);
                return false;
            } else {
                return true;
            }
        })).pipe(take(1));
    }

    canLoad(rout: Route) {
        if (this.store.select(fromRoot.getIsAuthenticated)) {
            return true;
        } else {
            this.router.navigate(['/index']);
        }
    }

}